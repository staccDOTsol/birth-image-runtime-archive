#!/bin/sh
# Guest entrypoint. Everything that needs shell variables lives here, not in the compose,
# because docker-compose interpolates $ in the YAML before the container ever runs.
set -u
PORT_NUM="${PORT:-8787}"
export AGENT_HTTP_PORT="$PORT_NUM"
echo "start $(date -u) port=$AGENT_HTTP_PORT" > /tmp/boot.log

cd /app || { echo "no /app" >> /tmp/boot.log; exit 1; }
# One supervisor per guest root. Without this, every relaunch adds another `while true`
# and the box ends up with dozens of orphaned node processes fighting over ~1 GB until
# the kernel OOMs them all (watchdog_exit=137).
LOCK="${AGENT_GUEST_ROOT:-/var/lib/agent}/supervisor.lock"
mkdir -p "$(dirname "$LOCK")" 2>/dev/null || true
if [ -e "$LOCK" ] && kill -0 "$(cat "$LOCK" 2>/dev/null)" 2>/dev/null; then
  echo "supervisor already alive pid=$(cat "$LOCK")" >> /tmp/boot.log
  exit 0
fi
echo $$ > "$LOCK"
trap 'rm -f "$LOCK"' EXIT INT TERM
# always take the published image, not whatever happens to be on disk from a previous boot
echo "image $(date -u) $AGENT_IMAGE_URL" >> /tmp/boot.log
wget -qO /tmp/img.tgz "$AGENT_IMAGE_URL" && tar xzf /tmp/img.tgz -C /app && echo "image_ok $(date -u)" >> /tmp/boot.log || echo "image_fail $(date -u)" >> /tmp/boot.log
AGENT_ROLE=boot node /app/agent.mjs >> /tmp/boot.log 2>&1
echo "boot_exit=$?" >> /tmp/boot.log

# Back off on repeated crashes: a box that cannot fit another worker should stop
# spawning them instead of OOM-killing in a tight loop all night.
fails=0
while true; do
  started=$(date +%s)
  AGENT_ROLE=watchdog node /app/agent.mjs >> /tmp/boot.log 2>&1
  code=$?
  ran=$(( $(date +%s) - started ))
  if [ "$ran" -lt 60 ]; then fails=$(( fails + 1 )); else fails=0; fi
  echo "watchdog_exit=$code ran=${ran}s fails=$fails $(date -u)" >> /tmp/boot.log
  if [ "$fails" -ge 5 ]; then
    echo "too many fast crashes; sleeping 120s $(date -u)" >> /tmp/boot.log
    sleep 120
    fails=0
  else
    sleep 10
  fi
done
